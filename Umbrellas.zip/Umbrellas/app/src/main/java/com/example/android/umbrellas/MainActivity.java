package com.example.android.umbrellas;

import android.content.Context;
import android.support.annotation.IdRes;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;


import static android.R.attr.borderlessButtonStyle;
import static android.R.attr.id;

public class MainActivity extends AppCompatActivity {
    //Create variables for each question - initialize score at zero
    int sc1 = 0;
    int sc2 = 0;
    int sc3 = 0;
    int sc4 = 0;
    int sc5 = 0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }


    //Validate Q1
    public void clicker_q1(View view) {
        sc1 = 0;
        RadioButton correct1 = (RadioButton) findViewById(R.id.answer1c);
        boolean isCorrect = correct1.isChecked();
        if (isCorrect) {
            sc1 += 1;
        }
    }

    //Validate Q2
    public void clicker_q2(View view) {
        sc2 = 0;
        RadioButton correct2 = (RadioButton) findViewById(R.id.answer2a);
        boolean isCorrect = correct2.isChecked();
        if (isCorrect) {
            sc2 += 1;

        }
    }

    //Validate Q3
    public void clicker_q3(View view) {
        sc3 = 0;
        RadioButton correct3 = (RadioButton) findViewById(R.id.answer3b);
        boolean isCorrect = correct3.isChecked();
        if (isCorrect) {
            sc3 += 1;
        }
    }


    //Validate Q4
    public void clicker_q4(View view) {
        sc4 = 0;
        String response4 = ((EditText) findViewById(R.id.answer4)).getText().toString().toUpperCase();
        boolean correct4 = getString(R.string.a4_string).equals(response4);
        if (correct4) {
            sc4 += 1;
        }
    }


    //Validate Q5 - correct answers are b., c. and e.
    public void clicker_q5(View view) {
        sc5 = 0;
        //5a is wrong when checked
        CheckBox a5a = (CheckBox) findViewById(R.id.answer5a);
        boolean isFalse5a = a5a.isChecked();
        //5b is CORRECT when checked
        CheckBox correct5b = (CheckBox) findViewById(R.id.answer5b);
        boolean isCorrect5b = correct5b.isChecked();
        //5c is CORRECT when checked
        CheckBox correct5c = (CheckBox) findViewById(R.id.answer5c);
        boolean isCorrect5c = correct5c.isChecked();
        //5d is wrong when checked
        CheckBox a5d = (CheckBox) findViewById(R.id.answer5d);
        boolean isFalse5d = a5d.isChecked();
        //5e is CORRECT when checked
        CheckBox correct5e = (CheckBox) findViewById(R.id.answer5e);
        boolean isCorrect5e = correct5e.isChecked();
        //1pt is earned when only the CORRECT answers are checked
        if (!isFalse5a && isCorrect5b && isCorrect5c && !isFalse5d && isCorrect5e) {
            sc5 += 1;
        }
    }


    //Show totalScore toast on screen when SHOW MY RESULTS! is pressed
    public void myResults(View view) {
        int totalScore = sc1 + sc2 + sc3 + sc4 + sc5;
        String message = getString(R.string.score_toast1) + " " + totalScore + " " + getString(R.string.score_toast2);
        Context context = getApplicationContext();
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, message, duration);
        toast.show();
    }


//END OF FILE CURLY PARENTHESIS
}
